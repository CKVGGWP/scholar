<?php
session_start();
include 'db_user.php';

if (isset($_GET['token'])){
    $token = $_GET['token'];
    $verify_query = "SELECT verify_token FROM accountinformation WHERE verify_token = '$token' LIMIT 1";
    $verify_query_run = mysqli_query($conn, $verify_query);

    if (mysqli_num_rows($verify_query_run) > 0){

        $row = mysqli_fetch_array($verify_query_run);
        echo $row['verify_token'];

    }  else{
        $_SESSION['status'] = "This token does not exists";
        header("location: ../registrationform.php");
    }
}

?>